package csueb.cs453.dual_fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondFragment extends Fragment {
    TextView mText;
    Button mButton;
    Button mButtonReset;
    int count = 0;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
    }

    @Override
    public View onCreateView(LayoutInflater l, ViewGroup vg, Bundle b) {
        View v = l.inflate(R.layout.fragment_second, vg, false);
        mText = (TextView)v.findViewById(R.id.text_view);
        mButton = (Button)v.findViewById(R.id.go_button);
        mButtonReset = (Button)v.findViewById(R.id.reset_button);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = count+5;
                mText.setText(count+"");
            }
        });

        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 0;
                mText.setText(count+"");
            }
        });

        return v;
    }
}
