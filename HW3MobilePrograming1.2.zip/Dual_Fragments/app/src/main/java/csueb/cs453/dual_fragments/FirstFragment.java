package csueb.cs453.dual_fragments;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class FirstFragment extends Fragment {
    TextView mEdit;
    Button mButton1;
    Button mButton5;
    Button mButtonReset;
    int count = 0;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
    }

    @Override
    public View onCreateView(LayoutInflater l, ViewGroup vg, Bundle b) {
        //The third parameter tells the layout inflater
        //whether to add the inflated view to the
        //view’s parent. You pass in false
        //because you will add the view in the
        //activity’s code.
        View v = l.inflate(R.layout.fragment_first, vg, false);

        mEdit = (TextView)v.findViewById(R.id.edit_text);
        mButton1 = (Button)v.findViewById(R.id.go1_button);
        mButton5 = (Button)v.findViewById(R.id.go5_button);
        mButtonReset = (Button)v.findViewById(R.id.reset_button);
        //mButton.setVisibility(View.VISIBLE);

        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                mEdit.setText(count+"");

            }
        });

        mButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = count+5;
                mEdit.setText(count+"");
            }
        });

        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 0;
                mEdit.setText(count+"");
            }
        });


        return v;
    }

}
