package csueb.cs453.dual_fragments;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        FragmentManager fm = getSupportFragmentManager();

        // check if the first fragment already exists.
        // if it doesn't, instantiate one and then give it
        // to the fragment manager.
        Fragment f = fm.findFragmentById(R.id.fragment_one_container);
        if(f == null) {
            f = new FirstFragment();
            fm.beginTransaction().add(R.id.fragment_one_container, f).commit();
        }

        // check if the second fragment already exists
        // if it doesn't, instantiate one and then give it
        // to the fragment manager.
        /*f = fm.findFragmentById(R.id.fragment_two_container);
        if (f == null) {
            f = new SecondFragment();
            fm.beginTransaction().add(R.id.fragment_two_container, f).commit();
        }*/
    }
}
