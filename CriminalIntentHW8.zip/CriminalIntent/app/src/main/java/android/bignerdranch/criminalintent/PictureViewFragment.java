package android.bignerdranch.criminalintent;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;

public class PictureViewFragment {

    private static final String EXTRA_IMAGE = "com.bignerdranch.android.criminalintent.image";

    private static final String ARG_IMAGE = "image";

    Bitmap photo;

    public static android.bignerdranch.criminalintent.PictureViewFragment newInstance(Bitmap bm) {

        Bundle args = new Bundle();

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100,stream);

        byte[] byteArray = stream.toByteArray();
        args.putByteArray(ARG_IMAGE,byteArray);
        android.bignerdranch.criminalintent.PictureViewFragment fragment = new android.bignerdranch.criminalintent.PictureViewFragment();
        fragment.setArguments(args);
        return fragment;


    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        View v = LayoutInflater.from(getActivity).inflate(R.layout.dialog_image, null);

        mPhotoView = (ImageView)v.findViewById(R.id.image_dialog);

        byte[] byteArray = getArguments().getByteArray(ARG_IMAGE);
        Bitmap bm = BitmapFactory.decodeByteArray(byteArray,0,byteArray.length);
        mPhotoView.setImageBitmap(bm);

        return new AlertDialog.Builder(getActivity())
                .setView(v)
                .setTitle(R.string.zoom_picture)
                .setPositiveButton(android.R.string.ok, null)
                .create();





    }


}
